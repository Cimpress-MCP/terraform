#!/usr/bin/env python

# Created by Wazuh, Inc. <info@wazuh.com>.
# This program is a free software; you can redistribute it and/or modify it under the terms of GPLv2

__version__ = '3.2.4'
__revision__ = '0901'
__author__ = "Wazuh Inc"
__ossec_name__ = "Wazuh"
__licence__ = "\
This program is free software; you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License (version 2) as \n\
published by the Free Software Foundation. For more details, go to \n\
https://www.gnu.org/licenses/gpl.html\n"
